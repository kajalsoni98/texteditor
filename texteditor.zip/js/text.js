// JavaScript Document

//textField.document.designMode="on";
function foo(){
	var opj;
	opj=document.getElementById("output").innerHTML;
	
const selobj=window.getSelection();
const selRange=selobj.getRangeAt(0);
	
	let slo=opj.findindexOf("selobj",0);
	let slol=opj.findlastIndexOf('selobj');
	alert(slo);
	//alert(selRange);
	/*if(target.style.textDecoration=="none"){
		target.style.textDecoration="underline";
		
	}else{
		target.style.textDecoration="none";
	}*/
}
